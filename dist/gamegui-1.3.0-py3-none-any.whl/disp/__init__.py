from pygame.display import flip as update,update as updateportion
