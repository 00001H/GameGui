# GameGui
This is an advanced game engine.
Currently looking for collaborators.
The demo folder contains the demos so that you can learn the usage.

Requires `pygame 2.0.0+` to function.
